var t1 = 300;
var t2 = 300;
var t3 = 400;

let comision1 = t1 * parseInt(1);
let comision2 = t2 * parseInt(3);
let comision3 = t3 * parseInt(5);

console.log("300 * 1");
console.log("300 * 3");
console.log("400 * 5");

console.log("===================");

console.log(comision1);
console.log(comision2);
console.log(comision3);

console.log("--------------");

let ComisionT = comision1 + comision2 + comision3;

console.log("El total que se debe pagar es de: " + ComisionT);
